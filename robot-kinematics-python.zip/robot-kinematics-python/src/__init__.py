"""Robot Kinematics — 2-DOF Planar Arm."""
from .forward_kinematics import fk_geometric, fk_dh, dh_transform
from .inverse_kinematics import ik_2dof, is_reachable

__all__ = ['fk_geometric', 'fk_dh', 'dh_transform', 'ik_2dof', 'is_reachable']
__version__ = '0.1.0'
__author__ = 'A. Ramkumar (techwithramkumar)'
