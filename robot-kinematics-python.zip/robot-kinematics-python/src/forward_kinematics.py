"""
Forward Kinematics — 2-DOF Planar Robot Arm
============================================

Computes end-effector (x, y) position from joint angles using
geometric and DH-parameter methods. Includes visualization.

Author : A. Ramkumar (techwithramkumar)
Course : Industrial Robotics & Mechatronics
College: Kumaraguru College of Technology, Coimbatore
License: MIT

Run:    python src/forward_kinematics.py
"""

import os
import numpy as np
import matplotlib.pyplot as plt


# ─────────────────────────────────────────────────────────────
#  CORE FK FUNCTIONS
# ─────────────────────────────────────────────────────────────

def fk_geometric(theta1, theta2, L1=1.0, L2=1.0):
    """
    Geometric Forward Kinematics for a 2-DOF planar arm.

    Parameters
    ----------
    theta1, theta2 : float
        Joint angles in radians.
    L1, L2 : float
        Link lengths (default 1.0 each).

    Returns
    -------
    (x, y) : tuple of float
        End-effector coordinates.
    """
    x = L1 * np.cos(theta1) + L2 * np.cos(theta1 + theta2)
    y = L1 * np.sin(theta1) + L2 * np.sin(theta1 + theta2)
    return x, y


def dh_transform(theta, d, a, alpha):
    """
    Standard Denavit-Hartenberg transformation matrix.

    Parameters
    ----------
    theta : float   (joint angle, radians)
    d     : float   (link offset)
    a     : float   (link length)
    alpha : float   (link twist, radians)

    Returns
    -------
    T : (4,4) ndarray  — homogeneous transformation matrix
    """
    ct, st = np.cos(theta), np.sin(theta)
    ca, sa = np.cos(alpha), np.sin(alpha)
    return np.array([
        [ct, -st * ca,  st * sa, a * ct],
        [st,  ct * ca, -ct * sa, a * st],
        [0,       sa,       ca,      d],
        [0,        0,        0,      1]
    ])


def fk_dh(theta1, theta2, L1=1.0, L2=1.0):
    """
    DH-based Forward Kinematics for a 2-DOF planar arm.
    Returns end-effector (x, y) — should match fk_geometric().
    """
    T1 = dh_transform(theta1, 0, L1, 0)
    T2 = dh_transform(theta2, 0, L2, 0)
    T  = T1 @ T2
    return T[0, 3], T[1, 3]


# ─────────────────────────────────────────────────────────────
#  VISUALIZATION
# ─────────────────────────────────────────────────────────────

def plot_arm(theta1, theta2, L1=1.0, L2=1.0, save_path=None):
    """Plot the 2-DOF arm at given joint configuration."""
    # Joint positions
    j0 = (0, 0)
    j1 = (L1 * np.cos(theta1), L1 * np.sin(theta1))
    j2 = fk_geometric(theta1, theta2, L1, L2)

    fig, ax = plt.subplots(figsize=(7, 7))
    ax.plot([j0[0], j1[0], j2[0]],
            [j0[1], j1[1], j2[1]],
            'o-', linewidth=4, markersize=12, color='#0066CC')
    ax.plot(j2[0], j2[1], 's', markersize=14, color='#CC0033', label='End-effector')
    ax.plot(0, 0, 'k^', markersize=14, label='Base')

    reach = L1 + L2 + 0.5
    ax.set_xlim(-reach, reach)
    ax.set_ylim(-reach, reach)
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)
    ax.legend(loc='upper right')
    ax.set_title(
        f'2-DOF Planar Arm  |  θ₁ = {np.degrees(theta1):.0f}°, '
        f'θ₂ = {np.degrees(theta2):.0f}°  |  EE = ({j2[0]:.2f}, {j2[1]:.2f})',
        fontsize=12
    )
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=120, bbox_inches='tight')
        print(f"Saved → {save_path}")
    plt.show()


def plot_workspace(L1=1.0, L2=1.0, n=60, save_path=None):
    """Sweep all joint angles and plot the reachable workspace."""
    theta1_range = np.linspace(0, 2 * np.pi, n)
    theta2_range = np.linspace(0, 2 * np.pi, n)

    xs, ys = [], []
    for t1 in theta1_range:
        for t2 in theta2_range:
            x, y = fk_geometric(t1, t2, L1, L2)
            xs.append(x); ys.append(y)

    fig, ax = plt.subplots(figsize=(7, 7))
    ax.scatter(xs, ys, s=2, alpha=0.4, color='#0066CC')
    ax.set_aspect('equal')
    ax.grid(True, alpha=0.3)
    ax.set_title(f'Reachable Workspace  |  L₁={L1}, L₂={L2}', fontsize=12)
    ax.set_xlabel('X (m)')
    ax.set_ylabel('Y (m)')

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=120, bbox_inches='tight')
        print(f"Saved → {save_path}")
    plt.show()


# ─────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 56)
    print("  Forward Kinematics — 2-DOF Planar Robot Arm")
    print("  A. Ramkumar | KCT Coimbatore")
    print("=" * 56)

    # Test 1 — verify both methods agree
    t1, t2 = np.radians(45), np.radians(30)
    x_geo = fk_geometric(t1, t2)
    x_dh  = fk_dh(t1, t2)
    print(f"\n[Test] Geometric → ({x_geo[0]:.4f}, {x_geo[1]:.4f})")
    print(f"[Test] DH        → ({x_dh[0]:.4f}, {x_dh[1]:.4f})")
    assert np.allclose(x_geo, x_dh), "FK methods disagree!"
    print("[Test] ✓ Both methods match.\n")

    # Visualize one pose
    plot_arm(t1, t2, save_path='images/arm_pose.png')

    # Sweep the full workspace
    plot_workspace(save_path='images/workspace.png')
