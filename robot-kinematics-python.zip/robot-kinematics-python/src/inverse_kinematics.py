"""
Inverse Kinematics — 2-DOF Planar Robot Arm
============================================

Given a target (x, y), solve for joint angles (θ₁, θ₂).
Returns BOTH elbow-up and elbow-down solutions.
Includes reachability check and animated motion demo.

Author : A. Ramkumar (techwithramkumar)
Course : Industrial Robotics & Mechatronics
College: Kumaraguru College of Technology, Coimbatore
License: MIT

Run:    python src/inverse_kinematics.py
"""

import os
import numpy as np
import matplotlib.pyplot as plt

from forward_kinematics import fk_geometric


# ─────────────────────────────────────────────────────────────
#  REACHABILITY
# ─────────────────────────────────────────────────────────────

def is_reachable(x, y, L1=1.0, L2=1.0):
    """
    Check if a point (x, y) is inside the arm's reachable workspace.

    Reachable region is an annulus:
        |L1 - L2| <= r <= (L1 + L2),  where r = sqrt(x^2 + y^2)
    """
    r = np.hypot(x, y)
    return abs(L1 - L2) <= r <= (L1 + L2)


# ─────────────────────────────────────────────────────────────
#  ANALYTICAL IK (closed-form, geometric method)
# ─────────────────────────────────────────────────────────────

def ik_2dof(x, y, L1=1.0, L2=1.0):
    """
    Closed-form Inverse Kinematics for a 2-DOF planar arm.

    Returns
    -------
    solutions : list of (theta1, theta2) tuples in radians
                Empty list if (x, y) is unreachable.
                Otherwise contains two solutions:
                    [0] elbow-down (θ₂ > 0)
                    [1] elbow-up   (θ₂ < 0)
    """
    if not is_reachable(x, y, L1, L2):
        print(f"⚠ Target ({x:.2f}, {y:.2f}) is OUT of reach.")
        return []

    # cos(theta2) using law of cosines
    cos_t2 = (x**2 + y**2 - L1**2 - L2**2) / (2 * L1 * L2)
    cos_t2 = np.clip(cos_t2, -1.0, 1.0)  # guard against floating-point drift

    # Two solutions for theta2
    t2_down =  np.arccos(cos_t2)
    t2_up   = -np.arccos(cos_t2)

    solutions = []
    for t2 in (t2_down, t2_up):
        # Corresponding theta1
        k1 = L1 + L2 * np.cos(t2)
        k2 = L2 * np.sin(t2)
        t1 = np.arctan2(y, x) - np.arctan2(k2, k1)
        solutions.append((t1, t2))

    return solutions


# ─────────────────────────────────────────────────────────────
#  VISUALIZATION
# ─────────────────────────────────────────────────────────────

def plot_both_solutions(x, y, L1=1.0, L2=1.0, save_path=None):
    """Plot both elbow-up and elbow-down solutions side by side."""
    sols = ik_2dof(x, y, L1, L2)
    if not sols:
        return

    labels = ['Elbow Down', 'Elbow Up']
    colors = ['#0066CC', '#CC6600']
    fig, axes = plt.subplots(1, 2, figsize=(14, 7))

    for ax, (t1, t2), label, color in zip(axes, sols, labels, colors):
        j0 = (0, 0)
        j1 = (L1 * np.cos(t1), L1 * np.sin(t1))
        j2 = fk_geometric(t1, t2, L1, L2)

        ax.plot([j0[0], j1[0], j2[0]],
                [j0[1], j1[1], j2[1]],
                'o-', linewidth=4, markersize=12, color=color)
        ax.plot(x, y, 's', markersize=14, color='#CC0033', label='Target')
        ax.plot(0, 0, 'k^', markersize=14, label='Base')

        reach = L1 + L2 + 0.5
        ax.set_xlim(-reach, reach)
        ax.set_ylim(-reach, reach)
        ax.set_aspect('equal')
        ax.grid(True, alpha=0.3)
        ax.legend(loc='upper right')
        ax.set_title(
            f'{label}  |  θ₁={np.degrees(t1):.1f}°, θ₂={np.degrees(t2):.1f}°',
            fontsize=12
        )
        ax.set_xlabel('X (m)')
        ax.set_ylabel('Y (m)')

    fig.suptitle(f'IK Solutions for Target ({x}, {y})', fontsize=14, y=1.02)

    if save_path:
        os.makedirs(os.path.dirname(save_path), exist_ok=True)
        plt.savefig(save_path, dpi=120, bbox_inches='tight')
        print(f"Saved → {save_path}")
    plt.show()


# ─────────────────────────────────────────────────────────────
#  ENTRY POINT
# ─────────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 56)
    print("  Inverse Kinematics — 2-DOF Planar Robot Arm")
    print("  A. Ramkumar | KCT Coimbatore")
    print("=" * 56)

    # Test 1 — reachable target
    target = (1.2, 0.8)
    print(f"\nTarget: {target}")
    sols = ik_2dof(*target)
    for i, (t1, t2) in enumerate(sols, 1):
        x_check, y_check = fk_geometric(t1, t2)
        print(f"  Sol {i}: θ₁={np.degrees(t1):7.2f}°, "
              f"θ₂={np.degrees(t2):7.2f}°  →  FK check: ({x_check:.3f}, {y_check:.3f})")

    # Test 2 — unreachable target
    print(f"\nTarget: (5.0, 5.0) — should be unreachable")
    ik_2dof(5.0, 5.0)

    # Visualize
    plot_both_solutions(*target, save_path='images/ik_solutions.png')
