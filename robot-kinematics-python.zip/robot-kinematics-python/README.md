# 🤖 Robot Kinematics in Python — 2-DOF Planar Manipulator

> Forward and Inverse Kinematics for a 2-DOF planar robot arm — DH parameters, geometric method, and closed-form IK with both elbow-up and elbow-down solutions. Built for Mechatronics students learning robotics for the first time.

![Arm Pose](images/arm_pose.png)

---

## What this repo does

Three things, all runnable in under 5 minutes:

1. **Forward Kinematics** — Compute end-effector (x, y) from joint angles using both the geometric method and the standard Denavit–Hartenberg (DH) transformation. Both methods are cross-verified.
2. **Inverse Kinematics** — Closed-form analytical solution. Given a target (x, y), returns BOTH valid configurations (elbow-up and elbow-down). Includes reachability check.
3. **Workspace visualization** — Sweeps every joint configuration to plot the reachable region (the donut-shaped annulus you'll recognize from any robotics textbook).

If you've watched my [Forward & Inverse Kinematics video on YouTube](https://youtube.com/@techwithramkumar), this is the working code version of it — in Python instead of MATLAB.

## Who this is for

- Mechatronics / Robotics / Mechanical students learning **DH parameters** for the first time
- Engineers prepping for **robotics interview rounds** (FK / IK is asked in 80% of them)
- Self-learners who don't have a MATLAB license
- Anyone teaching an undergraduate robotics course who wants ready-to-use lab material

## Demo

| Forward Kinematics | Reachable Workspace | Inverse Kinematics (both solutions) |
|:---:|:---:|:---:|
| ![FK](images/arm_pose.png) | ![Workspace](images/workspace.png) | ![IK](images/ik_solutions.png) |

## How to run

```bash
git clone https://github.com/ramonmission/robot-kinematics-python.git
cd robot-kinematics-python
pip install -r requirements.txt

# Forward Kinematics — runs both methods, saves arm pose + workspace plots
python src/forward_kinematics.py

# Inverse Kinematics — solves IK for a target, shows both elbow configurations
python src/inverse_kinematics.py
```

That's it. Both scripts will run, print verification output, and save plots to `images/`.

## Project structure

```
robot-kinematics-python/
├── README.md
├── LICENSE                       (MIT)
├── requirements.txt
├── .gitignore
├── src/
│   ├── __init__.py
│   ├── forward_kinematics.py     ← FK (geometric + DH) + visualization
│   └── inverse_kinematics.py     ← Closed-form IK + both solutions
├── notebooks/
│   └── kinematics_walkthrough.ipynb  ← Step-by-step Colab notebook
├── tests/
│   └── test_kinematics.py        ← Unit tests for FK ↔ IK consistency
└── images/
    ├── arm_pose.png
    ├── workspace.png
    └── ik_solutions.png
```

## What you'll learn

- ✅ Build a homogeneous transformation matrix from DH parameters
- ✅ Compute end-effector position for any joint configuration (Forward Kinematics)
- ✅ Solve for joint angles given a target position (Inverse Kinematics — closed-form, geometric)
- ✅ Handle multiple IK solutions (elbow-up vs elbow-down) and choose between them
- ✅ Check workspace reachability before commanding a target
- ✅ Plot the reachable workspace of a 2-DOF arm

## Roadmap

- [ ] 3-DOF spatial manipulator (PUMA-style)
- [ ] Jacobian + velocity kinematics
- [ ] Trajectory planning (cubic + quintic polynomials)
- [ ] PyQt5 GUI for live joint-angle control
- [ ] Port to ROS2 with MoveIt2 integration

## Companion video

🎥 Tanglish walkthrough → [Forward & Inverse Kinematics — Step by Step](https://youtube.com/@techwithramkumar)

## Author

**A. Ramkumar** — Assistant Professor, Mechatronics Engineering, Kumaraguru College of Technology, Coimbatore
PhD researcher in Human-Robot Collaboration · IEEE RAS Faculty Coordinator · 16 years teaching

🎥 [@techwithramkumar](https://youtube.com/@techwithramkumar) · 💼 [LinkedIn](https://linkedin.com/in/ramkumar-a) · 📸 [Instagram](https://instagram.com/techwithramkumar)

## License

MIT — use it, fork it, teach with it. Just keep the credit.

---

*If this helped you, ⭐ the repo and tag me on LinkedIn — I'll feature your project on my page.*
