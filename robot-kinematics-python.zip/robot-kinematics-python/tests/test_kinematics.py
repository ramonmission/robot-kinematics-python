"""
Unit tests — verify FK and IK are mutually consistent.
Run:  python tests/test_kinematics.py
"""

import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', 'src'))

import numpy as np
from forward_kinematics import fk_geometric, fk_dh
from inverse_kinematics import ik_2dof, is_reachable


def test_fk_methods_agree():
    """Geometric and DH methods must produce identical end-effector positions."""
    test_angles = [(0, 0), (np.pi/4, np.pi/3), (np.pi/2, -np.pi/4), (np.pi, np.pi/2)]
    for t1, t2 in test_angles:
        x_geo = fk_geometric(t1, t2)
        x_dh  = fk_dh(t1, t2)
        assert np.allclose(x_geo, x_dh, atol=1e-9), \
            f"FK mismatch at ({t1}, {t2})"
    print("✓ test_fk_methods_agree")


def test_ik_inverts_fk():
    """For any reachable target, IK solutions must round-trip back through FK."""
    targets = [(1.2, 0.8), (0.5, 1.5), (-1.0, 0.5), (1.0, -1.0)]
    for x, y in targets:
        sols = ik_2dof(x, y)
        assert len(sols) == 2, f"Expected 2 solutions for ({x}, {y})"
        for t1, t2 in sols:
            x_check, y_check = fk_geometric(t1, t2)
            err = np.hypot(x_check - x, y_check - y)
            assert err < 1e-9, f"IK→FK round-trip failed at ({x}, {y}): err={err}"
    print("✓ test_ik_inverts_fk")


def test_unreachable_target():
    """Targets outside the workspace must return empty solution list."""
    assert ik_2dof(5.0, 5.0) == []      # far outside
    assert ik_2dof(3.0, 0.0) == []      # outside outer boundary
    # Note: (0, 0) IS reachable when L1 == L2 (arm folds back on itself)
    assert ik_2dof(0.5, 0.0, L1=1.0, L2=2.0) == []  # inside dead zone
    print("✓ test_unreachable_target")


def test_reachability_check():
    """is_reachable must correctly classify points."""
    assert is_reachable(1.0, 1.0)        # well inside
    assert is_reachable(2.0, 0.0)        # at outer boundary
    assert not is_reachable(3.0, 0.0)    # outside
    print("✓ test_reachability_check")


if __name__ == "__main__":
    print("Running kinematics tests...\n")
    test_fk_methods_agree()
    test_ik_inverts_fk()
    test_unreachable_target()
    test_reachability_check()
    print("\nAll tests passed ✓")
